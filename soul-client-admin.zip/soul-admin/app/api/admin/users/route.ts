import { NextResponse } from "next/server";
import { requireAdmin } from "../../../../lib/admin";

export async function GET() {
  try {
    const { admin }=await requireAdmin();
    const {data,error}=await admin.from("launcher_users").select("id,username,email,account_type,last_seen,instance_id,launcher_instances(name)").order("last_seen",{ascending:false});
    if(error)return NextResponse.json({error:error.message},{status:500});
    const users=(data??[]).map((u:any)=>({...u,instance_name:u.launcher_instances?.name??null}));
    return NextResponse.json({users});
  }catch(e:any){return NextResponse.json({error:e.message==="UNAUTHENTICATED"?"No autenticado":"No autorizado"},{status:e.message==="UNAUTHENTICATED"?401:403});}
}