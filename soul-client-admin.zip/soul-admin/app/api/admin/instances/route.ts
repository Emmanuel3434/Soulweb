import { NextResponse } from "next/server";
import { requireAdmin } from "../../../../lib/admin";

export async function GET() {
  try {
    const { admin } = await requireAdmin();
    const { data, error } = await admin.from("launcher_instances").select("*").order("created_at",{ascending:false});
    if(error) return NextResponse.json({error:error.message},{status:500});
    return NextResponse.json({instances:data??[]});
  } catch(e:any) {
    return NextResponse.json({error:e.message==="UNAUTHENTICATED"?"No autenticado":"No autorizado"},{status:e.message==="UNAUTHENTICATED"?401:403});
  }
}

export async function POST(req:Request) {
  try {
    const { admin } = await requireAdmin();
    const body=await req.json();
    if(!body.name?.trim()) return NextResponse.json({error:"El nombre es obligatorio"},{status:400});
    const { data,error }=await admin.from("launcher_instances").insert({
      name:body.name.trim(),version:body.version||"1.21.1",loader:body.loader||"fabric",
      visible:body.visible!==false,whitelist_enabled:body.whitelist_enabled===true
    }).select().single();
    if(error) return NextResponse.json({error:error.message},{status:500});
    return NextResponse.json({instance:data});
  } catch(e:any) { return NextResponse.json({error:e.message==="UNAUTHENTICATED"?"No autenticado":"No autorizado"},{status:e.message==="UNAUTHENTICATED"?401:403}); }
}

export async function PATCH(req:Request) {
  try {
    const { admin }=await requireAdmin(); const body=await req.json();
    const {error}=await admin.from("launcher_instances").update({visible:!!body.visible}).eq("id",body.id);
    if(error)return NextResponse.json({error:error.message},{status:500});
    return NextResponse.json({ok:true});
  }catch(e:any){return NextResponse.json({error:"No autorizado"},{status:403});}
}

export async function DELETE(req:Request) {
  try {
    const { admin }=await requireAdmin(); const body=await req.json();
    const {error}=await admin.from("launcher_instances").delete().eq("id",body.id);
    if(error)return NextResponse.json({error:error.message},{status:500});
    return NextResponse.json({ok:true});
  }catch(e:any){return NextResponse.json({error:"No autorizado"},{status:403});}
}