-- Ejecuta esto en Supabase SQL Editor.
-- Si tu launcher YA tiene tablas con otros nombres, adapta las consultas de
-- app/api/admin/users y app/api/admin/instances a tu esquema existente.

create extension if not exists pgcrypto;

create table if not exists public.app_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.launcher_instances (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  version text not null default '1.21.1',
  loader text not null default 'fabric',
  visible boolean not null default true,
  whitelist_enabled boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.launcher_users (
  id uuid primary key default gen_random_uuid(),
  username text not null,
  email text,
  account_type text not null default 'discord',
  last_seen timestamptz,
  instance_id uuid references public.launcher_instances(id) on delete set null,
  created_at timestamptz not null default now()
);

alter table public.app_admins enable row level security;
alter table public.launcher_instances enable row level security;
alter table public.launcher_users enable row level security;

-- El panel usa SUPABASE_SECRET_KEY exclusivamente en el servidor.
-- No expongas esa clave al navegador.
-- Estas políticas evitan acceso público accidental mediante la publishable key.

drop policy if exists "No public access to app_admins" on public.app_admins;
create policy "No public access to app_admins"
on public.app_admins for all
to anon, authenticated
using (false)
with check (false);

drop policy if exists "No public access to launcher_instances" on public.launcher_instances;
create policy "No public access to launcher_instances"
on public.launcher_instances for all
to anon, authenticated
using (false)
with check (false);

drop policy if exists "No public access to launcher_users" on public.launcher_users;
create policy "No public access to launcher_users"
on public.launcher_users for all
to anon, authenticated
using (false)
with check (false);

-- Después de crear tu cuenta de administrador en Supabase Auth:
-- insert into public.app_admins(user_id)
-- values ('UUID-DE-TU-USUARIO-AUTH');